package exceptions;

public class ExpertiseMismatchException extends Exception {
    public ExpertiseMismatchException(String message) {
        super(message);
    }
}
