package exceptions;

public class OverfeedException extends Exception {
    public OverfeedException(String message) {
        super(message);
    }
}
